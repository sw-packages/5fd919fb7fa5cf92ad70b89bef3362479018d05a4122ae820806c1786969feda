// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2017-2020 Egor Pugin <egor.pugin@gmail.com>

// used for preprocessing only
// move this file to frontend/sw or frontend/cpp dir?

#include <sw/driver/sw.h>
